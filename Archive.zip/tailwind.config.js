module.exports = {
  content: [
    "./src/**/*.{vue,js,ts,jsx,tsx}"
  ],
  safelist: [
    {
      pattern: /^uw-/,
      variants: ['hover', 'focus', 'active', 'disabled'],
    }
  ],
  theme: {
    extend: {
      screens: {
        "popup-sm": {"max": "639px"},
        "popup-lg": {"min": "640px", "max": "899px"},
        window: {"min": "900px"}
      },
      colors: {
        primary: {
          50: "#ffddbe",
          100: "#ffcda0",
          200: "#ffbd83",
          300: "#ffac66",
          400: "#ff9a4a",
          500: "#ff872c",
          600: "#de7622",
          700: "#be6518",
          800: "#9f540e",
          900: "#824406",
          950: "#663400"
        }
      },
      fontFamily: {
        sans: ["Heebo", "ui-sans-serif", "system-ui"],
        mono: ["Source Code Pro", "ui-monospace", "monospace"]
      }
    }
  }
}
