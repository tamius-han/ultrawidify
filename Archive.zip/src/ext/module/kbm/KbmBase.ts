import EventBus from '@/ext/module/EventBus';
import { ComponentLogger } from '@/ext/module/logging/ComponentLogger';
import Settings from '@/ext/module/settings/Settings';
import { SiteSettings } from '@/ext/module/settings/SiteSettings';
import { InputHandlingMode } from '@src/common/enums/InputHandlingMode.enum';
import { EventBusCommand } from '@src/common/interfaces/EventBusMessage.interface';

export class KbmBase {
  listenFor: string[] = [];
  logger: ComponentLogger;
  settings: Settings;
  siteSettings: SiteSettings;
  eventBus: EventBus;

  element: HTMLElement | Document | undefined;

  eventBusCommands: { [x: string]: EventBusCommand } = {
    'kbm-enable': {
      function: () => this.enable()
    },
    'kbm-disable': {
      function: () => this.disable()
    },
    'kbm-set-config': {
      function: (data: {config: any, temporary?: boolean}) => this.setConfig(data.config, data.temporary),
    },
    'uw-enable': {
      function: () => this.load()
    },
    'uw-disable': {
      function: () => this.disable()
    },
  }

  constructor(eventBus: EventBus, siteSettings: SiteSettings, settings: Settings, logger: ComponentLogger) {
    this.logger = logger;
    this.siteSettings = siteSettings;
    this.settings = settings;
    this.eventBus = eventBus;
  }

  /**
   * Enables KeyboardHandler
   */
  enable() {
    this.load();
  }

  /**
   * Disables KeyboardHandler
   */
  disable() {
    this.removeListener();
  }

  /**
   * Sets configuration parameter for KeyboardHandler
   * @param config
   */
  setConfig(config, temporary = false) {
    if (temporary) {
      for (const confKey in config) {
        switch (confKey) {
          case 'enabled':
            config[confKey] ? this.enable() : this.disable();
            break;
        }
      }
      return;
    }

    for (const confKey in config) {
      this.settings.active.kbm[confKey] = config[confKey];
    }

    this.settings.save();
    this.load();
  }

  // convenience methods
  addListener(element: HTMLElement | Document = document) {
    // events should be handled in handleEvent function. We need to do things this
    // way, otherwise we can't remove event listener
    // https://stackoverflow.com/a/19507086

    if (!this.siteSettings) {

    }

    const enableInput = this.siteSettings.data.enableKeyboard;

    if (enableInput === InputHandlingMode.Disabled) {
      return;
    }

    this.element = element;
    for (const ev of this.listenFor) {
      element.addEventListener(
        ev,
        this
      );
    }
  }

  removeListener() {
    for (const ev of this.listenFor) {
      this.element?.removeEventListener(ev, this);
    }
  }

  load() {
    // if (! (this.settings.isEnabledForSite() && this.settings.active.kbm.enabled)) {
    //   return;
    // }
    // todo: detect if this is enabled or not
    if (!this.siteSettings) {
      console.warn('Site settings are undefined!');
      return;
    }
    this.addListener();
  }

  handleEvent(event) {
    console.error('[KbmBase::handleEvent] — IF YOU SEE THIS, THEN YOU KINDA FORGOT TO DEFINE A FUNCTION. Classes that extend KbmBase should also override this function.');
    throw "KBM_BASE::HANDLE_EVENT - OVERRIDE_ME_PLS";
  }
}

export default KbmBase;
