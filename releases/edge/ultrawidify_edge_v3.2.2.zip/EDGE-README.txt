How to install:

1. Unzip ultrawidify_edge_{version}.zip
2. Open Edge, type 'about:flags' in the address bar, hit enter
3. tick 'Enable extension developer features'
4. open 'Extensions' page in Edge (three dots under 'close' button -> Extensions)
5. Scroll to the bottom of the sidebar, click 'Load extension'
6. Select folder in which you extracted ultrawidify

Hurray, you installed Ultrawidify on edge.

On subsequent launches of Edge, there'll be a popup at the bottom of the page.
The popup will say:
	"We've turned off extensions from unknown sources They might 
	 be risky, so we recommend keeping them off."
Click 'Turn on anyway'. If you're on Netflix or Firefox, reload the page because
extension won't work until them.


You'll have to suffer this because I refuse to pay Microsoft �14 to basically give
me cancer. I'm super duper _not_ paying money for what's basically a broken product.

Refer to this comment for more details on this matter:
	https://github.com/xternal7/ultrawidify/issues/14#issuecomment-424903335

